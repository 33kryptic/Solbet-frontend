
🎰 BetSol - Full Solana Casino Platform

Includes:
- Coinflip (PvP and Bot)
- Jackpot Game
- Auth System (Username, Email, Wallet)
- Degen Chat (Emotes + Emojis)
- Leaderboards
- 10% Referral Rewards
- Terms & Support Pages
